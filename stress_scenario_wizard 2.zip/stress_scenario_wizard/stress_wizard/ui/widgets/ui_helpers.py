from __future__ import annotations

from PySide6.QtWidgets import (
    QAbstractItemView,
    QAbstractScrollArea,
    QFrame,
    QHeaderView,
    QScrollArea,
    QTableView,
    QVBoxLayout,
    QWidget,
)


def make_scrollable_layout(host: QWidget) -> QVBoxLayout:
    """Attach a vertical scroll container and return the content layout."""
    outer = QVBoxLayout(host)
    outer.setContentsMargins(0, 0, 0, 0)
    outer.setSpacing(0)

    scroll = QScrollArea(host)
    scroll.setWidgetResizable(True)
    scroll.setFrameShape(QFrame.Shape.NoFrame)
    scroll.setHorizontalScrollBarPolicy(scroll.horizontalScrollBarPolicy())

    content = QWidget(scroll)
    scroll.setWidget(content)
    outer.addWidget(scroll)

    layout = QVBoxLayout(content)
    layout.setContentsMargins(12, 10, 12, 10)
    layout.setSpacing(10)
    return layout


def configure_table_view(table: QTableView, sorting: bool = False) -> None:
    table.setAlternatingRowColors(True)
    table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
    table.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
    table.setShowGrid(False)
    table.setWordWrap(False)
    table.setHorizontalScrollMode(QAbstractItemView.ScrollMode.ScrollPerPixel)
    table.setVerticalScrollMode(QAbstractItemView.ScrollMode.ScrollPerPixel)
    table.setSizeAdjustPolicy(QAbstractScrollArea.SizeAdjustPolicy.AdjustToContentsOnFirstShow)
    table.setSortingEnabled(sorting)

    h = table.horizontalHeader()
    h.setSectionResizeMode(QHeaderView.ResizeMode.Interactive)
    h.setStretchLastSection(True)
    h.setMinimumSectionSize(90)

    v = table.verticalHeader()
    v.setVisible(False)
    v.setDefaultSectionSize(24)
