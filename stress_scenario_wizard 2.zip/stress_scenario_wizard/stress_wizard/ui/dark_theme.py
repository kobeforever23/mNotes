from __future__ import annotations


DARK_STYLESHEET = """
QWidget {
    background-color: #0c1422;
    color: #dde6f4;
    font-family: "Segoe UI";
    font-size: 11px;
}
QMainWindow, QDialog {
    background-color: #09101c;
}
QMenuBar {
    background-color: #0f1a2b;
    border-bottom: 1px solid #1d2b43;
}
QMenuBar::item {
    padding: 6px 10px;
    background: transparent;
}
QMenuBar::item:selected {
    background-color: #19304d;
}
QMenu {
    background-color: #0f1a2b;
    border: 1px solid #223552;
}
QMenu::item:selected {
    background-color: #1e3a5c;
}
QToolTip {
    background-color: #203b5c;
    color: #f3f7ff;
    border: 1px solid #4d6f98;
    padding: 4px;
}
QTabWidget::pane {
    border: 1px solid #1f314c;
    background: #0e1828;
}
QTabBar::tab {
    background: #13243a;
    color: #a8b8cf;
    border: 1px solid #213551;
    border-bottom: none;
    padding: 7px 13px;
    margin-right: 2px;
    min-width: 120px;
}
QTabBar::tab:selected {
    background: #1f3f64;
    color: #f6f9ff;
}
QTabBar::tab:hover:!selected {
    background: #17304d;
}
QGroupBox {
    border: 1px solid #2a4366;
    border-radius: 6px;
    margin-top: 12px;
    padding: 10px;
    background-color: #0d1626;
}
QGroupBox::title {
    subcontrol-origin: margin;
    left: 10px;
    padding: 0 6px;
    color: #8fc7ff;
    font-weight: 600;
}
QLabel {
    color: #cfdcf0;
}
QPushButton {
    background-color: #1e4b7c;
    color: #f5f9ff;
    border: 1px solid #35679e;
    border-radius: 5px;
    padding: 6px 12px;
}
QPushButton:hover {
    background-color: #27639f;
}
QPushButton:pressed {
    background-color: #1a4068;
}
QPushButton:disabled {
    background-color: #1a2638;
    border-color: #273b56;
    color: #7486a1;
}
QLineEdit, QTextEdit, QPlainTextEdit, QComboBox, QSpinBox, QDoubleSpinBox, QDateTimeEdit {
    background-color: #0b1626;
    border: 1px solid #2a4366;
    border-radius: 5px;
    padding: 4px;
    selection-background-color: #2f6daa;
    selection-color: #ffffff;
}
QLineEdit:focus, QTextEdit:focus, QPlainTextEdit:focus, QComboBox:focus, QSpinBox:focus, QDoubleSpinBox:focus, QDateTimeEdit:focus {
    border: 1px solid #4b85c2;
}
QComboBox::drop-down {
    border: 0px;
    width: 20px;
}
QTableView {
    background-color: #0c1523;
    alternate-background-color: #101d30;
    border: 1px solid #223653;
    gridline-color: #1b2a40;
    selection-background-color: #2f6daa;
    selection-color: #ffffff;
}
QTableCornerButton::section, QHeaderView::section {
    background-color: #162b46;
    color: #dce8fa;
    border: 1px solid #223a58;
    padding: 4px;
    font-weight: 600;
}
QScrollArea {
    border: none;
}
QScrollBar:vertical {
    background: #0c1522;
    width: 10px;
    margin: 2px;
}
QScrollBar::handle:vertical {
    background: #2a4c73;
    border-radius: 4px;
    min-height: 28px;
}
QScrollBar::handle:vertical:hover {
    background: #376391;
}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
    height: 0px;
}
QScrollBar:horizontal {
    background: #0c1522;
    height: 10px;
    margin: 2px;
}
QScrollBar::handle:horizontal {
    background: #2a4c73;
    border-radius: 4px;
    min-width: 28px;
}
QScrollBar::handle:horizontal:hover {
    background: #376391;
}
QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal {
    width: 0px;
}
QSplitter::handle {
    background-color: #1f2f47;
}
QSplitter::handle:horizontal {
    width: 6px;
}
QSplitter::handle:vertical {
    height: 6px;
}
QStatusBar {
    background: #0d1829;
    color: #9fc1e5;
    border-top: 1px solid #1f314c;
}
QProgressBar {
    border: 1px solid #2a4366;
    border-radius: 4px;
    text-align: center;
    background-color: #0b1626;
}
QProgressBar::chunk {
    background-color: #35a178;
}
"""
