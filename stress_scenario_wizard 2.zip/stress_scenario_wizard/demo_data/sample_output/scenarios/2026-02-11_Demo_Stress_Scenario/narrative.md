# Scenario Narrative: Demo Stress Scenario

## Economic Rationale
Demo package generated from built-in scenario state.

## Transmission Channels
Top-down asset shocks blended with bottom-up driver overrides.

## Calibration Methodology
Historical

## Key Assumptions
- Taylor expansion used for fast stress approximation

## Limitations
- Demo package may use sampled result previews for portability
